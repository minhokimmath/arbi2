import logging
import time
import hmac
import hashlib
import json
import requests
import threading
import tkinter as tk
from tkinter import ttk, messagebox
import customtkinter as ctk
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.dates as mdates
from PIL import Image, ImageTk
import numpy as np

# API 설정
TESTNET = True
API_KEY = "vlI5tQVnJwtTtkpXG6"
API_SECRET = "J6daTUFY3dCdNkWunHnCOPkfejTMhzezY5eo"
BASE_URL = "https://api-testnet.bybit.com" if TESTNET else "https://api.bybit.com"

# 거래 설정
TRADE_SETTINGS = {
    'symbol': 'BTCUSDT',
    'trade_amount': 0.001,
    'min_spread': 0.001,
    'max_spread': 0.01,
    'stop_loss': 0.005,
    'take_profit': 0.002,
    'leverage': 1,
    'interval': 1,
    'max_position': 0.005,
    'min_volume': 1000,
    'fee': 0.001,
}

class BybitArbitrage:
    def __init__(self):
        self.logger = logging.getLogger('BybitArbitrage')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler('trading.log')
        handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)
        self.session = requests.Session()
        self.session.headers.update({'Content-Type': 'application/json'})
        self.running = False
        self.trade_thread = None

    def _get_signature(self, params):
        try:
            timestamp = str(int(time.time() * 1000))
            params.update({'api_key': API_KEY, 'timestamp': timestamp, 'recv_window': '5000'})
            param_str = '&'.join(f"{k}={v}" for k, v in sorted(params.items()))
            signature = hmac.new(API_SECRET.encode(), param_str.encode(), hashlib.sha256).hexdigest()
            params['sign'] = signature
            return timestamp, signature, params
        except Exception as e:
            self.logger.error(f"Signature error: {e}")
            return None, None, None

    def _request(self, method, endpoint, params=None):
        try:
            timestamp, signature, params = self._get_signature(params or {})
            if not signature:
                return None
            url = f"{BASE_URL}{endpoint}"
            response = requests.request(method, url, params=params if method == 'GET' else json.dumps(params), headers={'Content-Type': 'application/json'})
            return response.json() if response.status_code == 200 else None
        except Exception as e:
            self.logger.error(f"Request error: {e}")
            return None

    def get_wallet_balance(self):
        response = self._request("GET", "/v5/account/wallet-balance", {'accountType': 'UNIFIED'})
        if response and 'result' in response:
            total_balance = float(response['result']['list'][0].get('totalWalletBalance', '0'))
            return {'total': total_balance, 'available': total_balance * 0.01}
        return None

    def get_market_price(self, symbol, category):
        response = self._request("GET", "/v5/market/tickers", {'category': category, 'symbol': symbol})
        if response and 'result' in response and 'list' in response['result']:
            return float(response['result']['list'][0]['lastPrice'])
        return None

    def execute_trade(self, symbol, spot_price, futures_price, amount):
        try:
            spread = (futures_price - spot_price) / spot_price * 100
            if spread > 0:
                spot_side, futures_side = "Buy", "Sell"
            else:
                spot_side, futures_side = "Sell", "Buy"
            spot_order = self._request("POST", "/v5/order/create", {'category': 'spot', 'symbol': symbol, 'side': spot_side, 'orderType': 'Market', 'qty': str(amount)})
            futures_order = self._request("POST", "/v5/order/create", {'category': 'linear', 'symbol': symbol, 'side': futures_side, 'orderType': 'Market', 'qty': str(amount)})
            return spot_order and futures_order
        except Exception as e:
            self.logger.error(f"Trade execution error: {e}")
            return None

if __name__ == "__main__":
    arbitrage_bot = BybitArbitrage()
    if arbitrage_bot.get_wallet_balance():
        arbitrage_bot.execute_trade("BTCUSDT", 50000, 50100, 0.001)
